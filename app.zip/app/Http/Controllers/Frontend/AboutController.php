<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\View\View;

class AboutController extends Controller
{
    /**
     * Show the about page.
     */
    public function index(): View
    {
        return view('frontend.about');
    }
}